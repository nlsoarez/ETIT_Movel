import React, { useState, useEffect } from 'react';
import { Search, AlertCircle, TrendingUp, Clock, Target, CheckCircle, FileText, Phone, Headphones, Activity } from 'lucide-react';

interface AnalystData {
  'Abertura RAL': number;
  'RAL': number;
  'REC': number;
  'Remedy Móvel': number;
  'TOA: 1ª Int.': number;
  'NICE: Recebido': number;
  'NICE: Atendido': number;
  'NICE: Realizado': number;
  'Total': number;
}

interface DatabaseType {
  [key: string]: AnalystData;
}

function App() {
  const [matricula, setMatricula] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [loading, setLoading] = useState(false);
  const [analystData, setAnalystData] = useState<AnalystData | null>(null);
  const [analysis, setAnalysis] = useState({ message: '', isAboveAverage: false });
  const [teamAverages, setTeamAverages] = useState<AnalystData | null>(null);

  useEffect(() => {
    // Load last searched registration number
    const lastMatricula = localStorage.getItem('ultimoLogin');
    if (lastMatricula) {
      setMatricula(lastMatricula);
    }
  }, []);

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      buscarDados();
    }
  };

  const getIndicatorIcon = (indicador: string) => {
    switch (indicador) {
      case 'Abertura RAL':
        return <FileText className="w-4 h-4" />;
      case 'RAL':
        return <FileText className="w-4 h-4" />;
      case 'REC':
        return <Phone className="w-4 h-4" />;
      case 'Remedy Móvel':
        return <Activity className="w-4 h-4" />;
      case 'TOA: 1ª Int.':
        return <Target className="w-4 h-4" />;
      case 'NICE: Recebido':
        return <Headphones className="w-4 h-4" />;
      case 'NICE: Atendido':
        return <Headphones className="w-4 h-4" />;
      case 'NICE: Realizado':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Activity className="w-4 h-4" />;
    }
  };

  const getRowStyle = (key: string, value: number) => {
    if (key === 'Total' || !teamAverages) return '';
    return value < teamAverages[key as keyof AnalystData]
      ? 'bg-red-50 text-red-700'
      : value > teamAverages[key as keyof AnalystData]
      ? 'bg-green-50 text-green-700'
      : '';
  };

  const buscarDados = () => {
    if (!matricula.trim()) {
      alert('Por favor, digite uma matrícula válida.');
      return;
    }

    setLoading(true);

    // Simulated database
    const dados: DatabaseType = {
      'N6071740': { 'Abertura RAL': 0, 'RAL': 0, 'REC': 0, 'Remedy Móvel': 418, 'TOA: 1ª Int.': 0, 'NICE: Recebido': 1, 'NICE: Atendido': 1, 'NICE: Realizado': 11, 'Total': 431 },
      'N6173067': { 'Abertura RAL': 61, 'RAL': 0, 'REC': 0, 'Remedy Móvel': 1260, 'TOA: 1ª Int.': 3, 'NICE: Recebido': 3, 'NICE: Atendido': 3, 'NICE: Realizado': 16, 'Total': 1346 },
      'N6172207': { 'Abertura RAL': 0, 'RAL': 0, 'REC': 0, 'Remedy Móvel': 1671, 'TOA: 1ª Int.': 4, 'NICE: Recebido': 1, 'NICE: Atendido': 1, 'NICE: Realizado': 0, 'Total': 1677 },
      'N6104793': { 'Abertura RAL': 52, 'RAL': 1, 'REC': 0, 'Remedy Móvel': 880, 'TOA: 1ª Int.': 0, 'NICE: Recebido': 2, 'NICE: Atendido': 0, 'NICE: Realizado': 24, 'Total': 959 },
      'N5931955': { 'Abertura RAL': 0, 'RAL': 0, 'REC': 0, 'Remedy Móvel': 0, 'TOA: 1ª Int.': 39, 'NICE: Recebido': 0, 'NICE: Atendido': 0, 'NICE: Realizado': 7, 'Total': 46 },
      'F204763': { 'Abertura RAL': 0, 'RAL': 0, 'REC': 0, 'Remedy Móvel': 1793, 'TOA: 1ª Int.': 5, 'NICE: Recebido': 10, 'NICE: Atendido': 9, 'NICE: Realizado': 28, 'Total': 1845 }
    };

    setTimeout(() => {
      const analyst = dados[matricula];
      
      if (!analyst) {
        alert('Matrícula não encontrada.');
        setLoading(false);
        return;
      }

      // Save last searched registration number
      localStorage.setItem('ultimoLogin', matricula);

      // Calculate team averages
      const totalAnalysts = Object.keys(dados).length;
      const averages = Object.keys(dados[Object.keys(dados)[0]]).reduce((acc, key) => {
        acc[key as keyof AnalystData] = Object.values(dados).reduce((sum, curr) => sum + curr[key as keyof AnalystData], 0) / totalAnalysts;
        return acc;
      }, {} as AnalystData);

      setTeamAverages(averages);
      setAnalystData(analyst);

      // Analyze performance
      const pontosFracos = Object.keys(analyst).filter(key => 
        key !== 'Total' && analyst[key as keyof AnalystData] < averages[key as keyof AnalystData]
      );

      const pontosFortesTemp = Object.keys(analyst).filter(key => 
        key !== 'Total' && analyst[key as keyof AnalystData] > averages[key as keyof AnalystData]
      );

      setAnalysis({
        message: analyst.Total > averages.Total
          ? `Parabéns! Você está acima da média da equipe. Seus pontos fortes: ${pontosFortesTemp.join(', ')}. Continue assim!`
          : `Atenção! Você está abaixo da média. Pontos a melhorar: ${pontosFracos.join(', ')}. Foco nesses indicadores!`,
        isAboveAverage: analyst.Total > averages.Total
      });

      setShowResults(true);
      setLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <img
              src="https://www.eventos.momentoeditorial.com.br/wp-content/uploads/2020/07/logo-Claro-800x600px.png"
              alt="Logo Claro"
              className="h-16 mx-auto mb-6"
            />
            <h1 className="text-2xl font-bold text-red-700">
              Consulta de Indicadores
            </h1>
          </div>

          {/* Search Input */}
          <div className="space-y-4 max-w-lg mx-auto">
            <div className="relative">
              <input
                type="text"
                value={matricula}
                onChange={(e) => setMatricula(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Digite a matrícula"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all"
              />
              <Search className="absolute right-3 top-3 text-gray-400" size={20} />
            </div>
            <button
              onClick={buscarDados}
              disabled={loading}
              className="w-full bg-gradient-to-r from-red-700 to-red-600 text-white py-3 rounded-lg font-semibold hover:from-red-800 hover:to-red-700 transform active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {loading ? 'Consultando...' : 'Consultar'}
            </button>
          </div>

          {/* Results */}
          {showResults && analystData && (
            <div className="mt-8 animate-fade-in">
              <div className="bg-gray-50 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">
                  Resultados
                </h2>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-red-700">
                        <th className="px-6 py-3 text-left text-sm font-semibold text-white">
                          Indicador
                        </th>
                        <th className="px-6 py-3 text-right text-sm font-semibold text-white">
                          Valor
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {Object.entries(analystData).map(([key, value], index) => (
                        <tr
                          key={index}
                          className={`hover:bg-opacity-80 transition-colors ${
                            key === 'Total' ? 'bg-gray-100 font-semibold' : ''
                          }`}
                        >
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2 text-gray-800">
                              {getIndicatorIcon(key)}
                              <span>{key}</span>
                            </div>
                          </td>
                          <td className={`px-6 py-4 text-right ${getRowStyle(key, value)}`}>
                            {value}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Analysis Section */}
                <div className={`mt-6 rounded-lg p-4 ${
                  analysis.isAboveAverage ? 'bg-green-50 border-l-4 border-green-500' : 'bg-yellow-50 border-l-4 border-yellow-500'
                }`}>
                  <div className="flex items-start gap-3">
                    <AlertCircle className={`flex-shrink-0 ${
                      analysis.isAboveAverage ? 'text-green-600' : 'text-yellow-600'
                    }`} size={20} />
                    <div>
                      <h3 className={`font-semibold mb-2 ${
                        analysis.isAboveAverage ? 'text-green-800' : 'text-yellow-800'
                      }`}>
                        Análise dos Indicadores
                      </h3>
                      <p className={`text-sm ${
                        analysis.isAboveAverage ? 'text-green-700' : 'text-yellow-700'
                      }`}>
                        {analysis.message}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Last Update */}
          <p className="text-sm text-gray-500 mt-8 text-center">
            Última atualização: 09/03
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;